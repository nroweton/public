# NFL Play Success Prediction

This project is a Flask web application for exploring NFL play outcomes. The
user selects game context, field position, formation, play type, and target/run
location on the web page. The browser sends that play information to Flask,
Flask runs the Python model logic in `backend/`, and the page displays the
predicted run or pass result.


## Project Structure

- `backend/` contains the run, pass, and YAC model code plus saved model/data
  files.
- `flaskapp/` contains the Flask application code, routes, templates, and
  static files.
- `flaskapp/routes.py` connects the web page to the backend model functions.
- `flaskapp/templates/final.html` is the main user interface.
- `run.py` starts the Flask development server.

## Dataset used:
https://www.kaggle.com/datasets/charliezimmerman/nfl-play-data-2010-2020?resource=download&select=play_by_play_2020.csv


## Application Flow
1. The user starts the flask server then opens`http://127.0.0.1:3001/`.
2. Flask handles `GET /` in `flaskapp/routes.py`.
3. Flask renders `flaskapp/templates/final.html`.
4. The user selects play settings and clicks the play button.
5. JavaScript sends a `POST` request to `/api/predict`.
6. Flask reads the JSON input, calls the backend model logic, and returns JSON.
7. JavaScript uses the response to update the field visualization.

## Libraries Needed


```text
Flask
numpy
pandas
scipy
scikit-learn (Must be 1.8.x and requires python >3.12)
joblib
matplotlib
```

## How to Run

Navigate to folder and start Flask server by running:

```bash
python run.py
```

Then open:

```text
http://127.0.0.1:3001/
```


Use `Ctrl+C` in the terminal to stop the Flask server.

